# quickLearn
nodejs, express, mongoDB

For windows:

## step 1

start mongodb service：

mongod -dbpath  'project data path'

## step 2

start nodejs service and connect mongodb:

`supervisor app.js`